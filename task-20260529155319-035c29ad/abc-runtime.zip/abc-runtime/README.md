BCE encrypted runtime package

Contents:
- app/plain-app.jar : encrypted application
- bce.properties : runtime configuration generated for this encrypted application
- license.bce : signed online license bound to one machine
- native/ : native runtime agent library only; bce-machine-id is intentionally not included
- scripts/ : start scripts for JAR/Spring Boot JAR and Tomcat WAR
- scripts/README.md : detailed script usage

Plain JAR bundle quick start:
1. Keep the app/ directory structure unchanged. The main JAR is app/plain-app.jar.
2. Start the application with scripts/bce-run-jar.sh. It reads app.main.jar from bce.properties and uses java -jar.
3. External dependency JARs stay at the relative paths declared by the main JAR manifest Class-Path.
4. The native agent validates license.bce online before startup.
The grant endpoint is configured inside license.bce.
