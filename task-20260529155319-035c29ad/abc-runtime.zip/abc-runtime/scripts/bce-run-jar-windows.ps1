$ErrorActionPreference = "Stop"

function Show-Usage {
  @"
Usage:
  .\bce-run-jar-windows.ps1 [--jar app\app_encrypted.jar] [--] [application args...]

Examples:
  .\bce-run-jar-windows.ps1
  .\bce-run-jar-windows.ps1 --server.port=18080 --spring.profiles.active=prod
  `$env:BCE_JAVA_OPTS="-Xmx512m"; .\bce-run-jar-windows.ps1 --server.port=18080

Expected package layout:
  app\
  native\
  scripts\
  bce.properties
  license.bce

The native agent validates license.bce online before the application starts.
"@
}

function Get-ConfigMainJar {
  $Config = Join-Path $PackageDir "bce.properties"
  if (-not (Test-Path $Config)) {
    return $null
  }
  $Line = Get-Content $Config | Where-Object { $_.StartsWith("app.main.jar=") } | Select-Object -First 1
  if ([string]::IsNullOrWhiteSpace($Line)) {
    return $null
  }
  $Value = $Line.Substring("app.main.jar=".Length).Trim()
  if ([string]::IsNullOrWhiteSpace($Value)) {
    return $null
  }
  if ([System.IO.Path]::IsPathRooted($Value)) {
    return $Value
  }
  return Join-Path (Join-Path $PackageDir "app") $Value
}

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$PackageDir = Resolve-Path (Join-Path $ScriptDir "..")
$Jar = $null
$AppArgs = @()

for ($i = 0; $i -lt $args.Count; $i++) {
  switch ($args[$i]) {
    "--jar" { $i++; $Jar = $args[$i]; continue }
    "-h" { Show-Usage; exit 0 }
    "--help" { Show-Usage; exit 0 }
    "--" { if ($i + 1 -lt $args.Count) { $AppArgs = $args[($i + 1)..($args.Count - 1)] }; break }
    default {
      if ($args[$i].StartsWith("-")) {
        $AppArgs = $args[$i..($args.Count - 1)]
      } elseif (-not $Jar -and $args[$i].ToLowerInvariant().EndsWith(".jar")) {
        $Jar = $args[$i]
        if ($i + 1 -lt $args.Count) { $AppArgs = $args[($i + 1)..($args.Count - 1)] }
      } else {
        $AppArgs = $args[$i..($args.Count - 1)]
      }
      break
    }
  }
}

if ([string]::IsNullOrWhiteSpace($Jar)) {
  $ConfigJar = Get-ConfigMainJar
  if (-not [string]::IsNullOrWhiteSpace($ConfigJar)) {
    if (-not (Test-Path $ConfigJar)) {
      Write-Error "app.main.jar in bce.properties does not exist under app\: $ConfigJar"
    }
    $Jar = $ConfigJar
  }
}

if ([string]::IsNullOrWhiteSpace($Jar)) {
  $Jars = Get-ChildItem -Path (Join-Path $PackageDir "app") -Filter "*.jar"
  if ($Jars.Count -ne 1) {
    Write-Error "Could not auto-detect encrypted JAR. Set app.main.jar, place exactly one JAR under app\, or pass --jar."
  }
  $Jar = $Jars[0].FullName
} elseif (-not (Test-Path $Jar)) {
  $JarInPackage = Join-Path (Join-Path $PackageDir "app") $Jar
  if (Test-Path $JarInPackage) {
    $Jar = $JarInPackage
  }
}

$NativeDir = Join-Path $PackageDir "native"
$Agent = Join-Path $NativeDir "bcekey.dll"
if (-not (Test-Path $Agent)) {
  $Agent = Join-Path $NativeDir "bce.dll"
}
$Core = Join-Path $ScriptDir "bce-core-run-jar-windows.ps1"

& $Core --jar $Jar --runtime-dir $PackageDir --agent $Agent -- @AppArgs
exit $LASTEXITCODE
