$ErrorActionPreference = "Stop"

function Show-Usage {
  @"
Usage:
  .\bce-core-run-tomcat-windows.ps1 --catalina-base <tomcat-dir> --runtime-dir <dir> --agent <native-agent> [--catalina-script <script>] [--] [catalina args...]

Required:
  --catalina-base  Tomcat base/home directory.
  --runtime-dir    directory containing bce.properties and license.bce.
  --agent          native agent path, such as bcekey.dll or bce.dll.

Options:
  --catalina-script catalina.bat path. Default: <tomcat-dir>\bin\catalina.bat.
"@
}

$CatalinaBase = $null
$RuntimeDir = $null
$Agent = $null
$CatalinaScript = $null
$CatalinaArgs = @()

for ($i = 0; $i -lt $args.Count; $i++) {
  switch ($args[$i]) {
    "--catalina-base" { $i++; $CatalinaBase = $args[$i]; continue }
    "--runtime-dir" { $i++; $RuntimeDir = $args[$i]; continue }
    "--agent" { $i++; $Agent = $args[$i]; continue }
    "--catalina-script" { $i++; $CatalinaScript = $args[$i]; continue }
    "-h" { Show-Usage; exit 0 }
    "--help" { Show-Usage; exit 0 }
    "--" { if ($i + 1 -lt $args.Count) { $CatalinaArgs = $args[($i + 1)..($args.Count - 1)] }; break }
    default { Write-Error "Unknown option: $($args[$i])" }
  }
}

if (-not (Test-Path $CatalinaBase)) { Show-Usage; Write-Error "Missing Tomcat directory: $CatalinaBase" }
if (-not (Test-Path $RuntimeDir)) { Show-Usage; Write-Error "Missing runtime directory: $RuntimeDir" }
if (-not (Test-Path (Join-Path $RuntimeDir "bce.properties"))) { Show-Usage; Write-Error "Missing runtime config: $(Join-Path $RuntimeDir "bce.properties")" }
if (-not (Test-Path (Join-Path $RuntimeDir "license.bce"))) { Show-Usage; Write-Error "Missing license: $(Join-Path $RuntimeDir "license.bce")" }
if (-not (Test-Path $Agent)) { Show-Usage; Write-Error "Missing native agent: $Agent" }

$CatalinaBase = (Resolve-Path $CatalinaBase).Path
$RuntimeDir = (Resolve-Path $RuntimeDir).Path
$Agent = (Resolve-Path $Agent).Path
if (-not $CatalinaScript) {
  $CatalinaScript = Join-Path $CatalinaBase "bin\catalina.bat"
}
if (-not (Test-Path $CatalinaScript)) { Show-Usage; Write-Error "Missing catalina script: $CatalinaScript" }

$NativeDir = Split-Path -Parent $Agent
$env:PATH = "$NativeDir;$env:PATH"
$env:CATALINA_BASE = $CatalinaBase
$env:CATALINA_OPTS = "$env:CATALINA_OPTS -XX:+DisableAttachMechanism -agentpath:$Agent=$RuntimeDir"

& $CatalinaScript run @CatalinaArgs
exit $LASTEXITCODE
