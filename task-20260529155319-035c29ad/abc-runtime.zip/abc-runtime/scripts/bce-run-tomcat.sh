#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'EOF'
Usage:
  ./bce-run-tomcat.sh [--] [catalina args...]
  sh bce-run-tomcat.sh [--] [catalina args...]

Copy this script and bce-core-run-tomcat.sh to TOMCAT_HOME/bin, then run it from there.

Expected Tomcat layout:
  bin/bce-run-tomcat.sh
  bin/bce-core-run-tomcat.sh
  lib/bce.properties
  lib/libbkey.dylib or lib/libbkey.so
  lib/license.bce

Important:
  Copy the platform native agent file itself from the package native/ directory
  into TOMCAT_HOME/lib. Do not copy the whole native directory as
  TOMCAT_HOME/lib/native; this script looks for lib/libbkey.dylib or
  lib/libbkey.so directly under TOMCAT_HOME/lib.

Options:
  -h, --help  show this help.
EOF
}

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TOMCAT_HOME="$(cd "$SCRIPT_DIR/.." && pwd)"
RUNTIME_DIR="$TOMCAT_HOME/lib"
while [ "$#" -gt 0 ]; do
  case "$1" in
    -h|--help)
      usage
      exit 0
      ;;
    --)
      shift
      break
      ;;
    -*)
      break
      ;;
    *)
      break
      ;;
  esac
done

case "$(uname -s)" in
  Darwin)
    AGENT="$RUNTIME_DIR/libbkey.dylib"
    ;;
  Linux)
    AGENT="$RUNTIME_DIR/libbkey.so"
    ;;
  *)
    echo "Unsupported OS. On Windows, use bce-run-tomcat-windows.ps1." >&2
    exit 1
    ;;
esac

CORE="$SCRIPT_DIR/bce-core-run-tomcat.sh"
[ -f "$CORE" ] || { echo "Missing core script: $CORE" >&2; usage; exit 1; }

exec sh "$CORE" \
  --catalina-base "$TOMCAT_HOME" \
  --runtime-dir "$RUNTIME_DIR" \
  --agent "$AGENT" \
  -- "$@"
