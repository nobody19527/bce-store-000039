$ErrorActionPreference = "Stop"

function Show-Usage {
  @"
Usage:
  .\bce-run-tomcat-windows.ps1 [--] [catalina args...]

Copy this script and bce-core-run-tomcat-windows.ps1 to TOMCAT_HOME\bin, then run it there.

Expected Tomcat layout:
  bin\bce-run-tomcat-windows.ps1
  bin\bce-core-run-tomcat-windows.ps1
  lib\bce.properties
  lib\license.bce
  lib\bcekey.dll

Important:
  Copy the platform native agent file itself from the package native\ directory
  into TOMCAT_HOME\lib. Do not copy the whole native directory as
  TOMCAT_HOME\lib\native; this script looks for lib\bcekey.dll directly under
  TOMCAT_HOME\lib.
"@
}

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$TomcatHome = Resolve-Path (Join-Path $ScriptDir "..")
$RuntimeDir = Join-Path $TomcatHome "lib"
$CatalinaArgs = @()

for ($i = 0; $i -lt $args.Count; $i++) {
  switch ($args[$i]) {
    "-h" { Show-Usage; exit 0 }
    "--help" { Show-Usage; exit 0 }
    "--" { if ($i + 1 -lt $args.Count) { $CatalinaArgs = $args[($i + 1)..($args.Count - 1)] }; break }
    default { $CatalinaArgs = $args[$i..($args.Count - 1)]; break }
  }
}

$Agent = Join-Path $RuntimeDir "bcekey.dll"
if (-not (Test-Path $Agent)) {
  $Agent = Join-Path $RuntimeDir "bce.dll"
}
$Core = Join-Path $ScriptDir "bce-core-run-tomcat-windows.ps1"

& $Core --catalina-base $TomcatHome --runtime-dir $RuntimeDir --agent $Agent -- @CatalinaArgs
exit $LASTEXITCODE
