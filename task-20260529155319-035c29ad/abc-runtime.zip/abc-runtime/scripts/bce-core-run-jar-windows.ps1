$ErrorActionPreference = "Stop"

function Show-Usage {
  @"
Usage:
  .\bce-core-run-jar-windows.ps1 --jar <encrypted-jar> --runtime-dir <dir> --agent <native-agent> [--java java] [--] [application args...]

Required:
  --jar          encrypted JAR path.
  --runtime-dir directory containing bce.properties and license.bce.
  --agent       native agent path, such as bcekey.dll or bce.dll.

Options:
  --java        Java command. Default: java.
"@
}

$Jar = $null
$RuntimeDir = $null
$Agent = $null
$JavaCmd = if ($env:JAVA_CMD) { $env:JAVA_CMD } else { "java" }
$AppArgs = @()

for ($i = 0; $i -lt $args.Count; $i++) {
  switch ($args[$i]) {
    "--jar" { $i++; $Jar = $args[$i]; continue }
    "--runtime-dir" { $i++; $RuntimeDir = $args[$i]; continue }
    "--agent" { $i++; $Agent = $args[$i]; continue }
    "--java" { $i++; $JavaCmd = $args[$i]; continue }
    "-h" { Show-Usage; exit 0 }
    "--help" { Show-Usage; exit 0 }
    "--" { if ($i + 1 -lt $args.Count) { $AppArgs = $args[($i + 1)..($args.Count - 1)] }; break }
    default { Write-Error "Unknown option: $($args[$i])" }
  }
}

if (-not (Test-Path $Jar)) { Show-Usage; Write-Error "Missing encrypted JAR: $Jar" }
if (-not (Test-Path $RuntimeDir)) { Show-Usage; Write-Error "Missing runtime directory: $RuntimeDir" }
if (-not (Test-Path (Join-Path $RuntimeDir "bce.properties"))) { Show-Usage; Write-Error "Missing runtime config: $(Join-Path $RuntimeDir "bce.properties")" }
if (-not (Test-Path (Join-Path $RuntimeDir "license.bce"))) { Show-Usage; Write-Error "Missing license: $(Join-Path $RuntimeDir "license.bce")" }
if (-not (Test-Path $Agent)) { Show-Usage; Write-Error "Missing native agent: $Agent" }

$Jar = (Resolve-Path $Jar).Path
$RuntimeDir = (Resolve-Path $RuntimeDir).Path
$Agent = (Resolve-Path $Agent).Path
$NativeDir = Split-Path -Parent $Agent
$env:PATH = "$NativeDir;$env:PATH"

$JavaOpts = @()
if ($env:BCE_JAVA_OPTS) {
  $JavaOpts = $env:BCE_JAVA_OPTS -split " "
}

$JavaArgs = @()
$JavaArgs += $JavaOpts
$JavaArgs += "-XX:+DisableAttachMechanism"
$JavaArgs += "-agentpath:$Agent=$RuntimeDir"
$JavaArgs += "-jar"
$JavaArgs += $Jar
$JavaArgs += $AppArgs

& $JavaCmd @JavaArgs
exit $LASTEXITCODE
