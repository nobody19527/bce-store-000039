@echo off
powershell -ExecutionPolicy Bypass -File "%~dp0bce-run-tomcat-windows.ps1" %*
pause
