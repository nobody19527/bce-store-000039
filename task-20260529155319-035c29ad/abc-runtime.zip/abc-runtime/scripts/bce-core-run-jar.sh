#!/usr/bin/env bash
set -euo pipefail

ulimit -c 0 2>/dev/null || true

usage() {
  cat <<'EOF'
Usage:
  ./bce-core-run-jar.sh --jar <encrypted-jar> --runtime-dir <dir> --agent <native-agent> [--java java] [--] [application args...]

Required:
  --jar          encrypted JAR path.
  --runtime-dir  directory containing bce.properties and license.bce.
  --agent        native agent path, such as libbkey.dylib or libbkey.so.

Application arguments after -- are passed to java -jar unchanged.
Set BCE_JAVA_OPTS for JVM options, for example:
  BCE_JAVA_OPTS="-Xmx512m" ./bce-core-run-jar.sh ...
EOF
}

APP_JAR=""
RUNTIME_DIR=""
AGENT=""
JAVA_CMD="${JAVA_CMD:-java}"

while [ "$#" -gt 0 ]; do
  case "$1" in
    --jar) APP_JAR="$2"; shift 2 ;;
    --runtime-dir) RUNTIME_DIR="$2"; shift 2 ;;
    --agent) AGENT="$2"; shift 2 ;;
    --java) JAVA_CMD="$2"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    --) shift; break ;;
    *) echo "Unknown option: $1" >&2; usage; exit 1 ;;
  esac
done

[ -f "$APP_JAR" ] || { echo "Missing encrypted JAR: $APP_JAR" >&2; usage; exit 1; }
[ -d "$RUNTIME_DIR" ] || { echo "Missing runtime directory: $RUNTIME_DIR" >&2; usage; exit 1; }
[ -f "$RUNTIME_DIR/bce.properties" ] || { echo "Missing runtime config: $RUNTIME_DIR/bce.properties" >&2; usage; exit 1; }
[ -f "$RUNTIME_DIR/license.bce" ] || { echo "Missing license: $RUNTIME_DIR/license.bce" >&2; usage; exit 1; }
[ -f "$AGENT" ] || { echo "Missing native agent: $AGENT" >&2; usage; exit 1; }

RUNTIME_DIR="$(cd "$RUNTIME_DIR" && pwd)"
APP_JAR="$(cd "$(dirname "$APP_JAR")" && pwd)/$(basename "$APP_JAR")"
AGENT="$(cd "$(dirname "$AGENT")" && pwd)/$(basename "$AGENT")"
NATIVE_DIR="$(cd "$(dirname "$AGENT")" && pwd)"

export DYLD_LIBRARY_PATH="$NATIVE_DIR:${DYLD_LIBRARY_PATH:-}"
export LD_LIBRARY_PATH="$NATIVE_DIR:${LD_LIBRARY_PATH:-}"

JAVA_ARGS=("$JAVA_CMD")
if [ -n "${BCE_JAVA_OPTS:-}" ]; then
  # shellcheck disable=SC2206
  EXTRA_JAVA_OPTS=($BCE_JAVA_OPTS)
  JAVA_ARGS+=("${EXTRA_JAVA_OPTS[@]}")
fi
JAVA_ARGS+=("-XX:+DisableAttachMechanism")
JAVA_ARGS+=("-agentpath:$AGENT=$RUNTIME_DIR")
JAVA_ARGS+=("-jar" "$APP_JAR")

exec "${JAVA_ARGS[@]}" "$@"
