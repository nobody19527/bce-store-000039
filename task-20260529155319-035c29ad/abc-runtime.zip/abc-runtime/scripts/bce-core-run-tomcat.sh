#!/usr/bin/env bash
set -euo pipefail

ulimit -c 0 2>/dev/null || true

usage() {
  cat <<'EOF'
Usage:
  ./bce-core-run-tomcat.sh --catalina-base <tomcat-dir> --runtime-dir <dir> --agent <native-agent> [--catalina-script <script>] [--] [catalina args...]

Required:
  --catalina-base  Tomcat base/home directory.
  --runtime-dir    directory containing bce.properties and license.bce.
  --agent          native agent path, such as libbkey.dylib or libbkey.so.

Options:
  --catalina-script catalina.sh path. Default: <tomcat-dir>/bin/catalina.sh.
  -h, --help        show this help.
EOF
}

CATALINA_BASE=""
RUNTIME_DIR=""
AGENT=""
CATALINA_SCRIPT=""

while [ "$#" -gt 0 ]; do
  case "$1" in
    --catalina-base) CATALINA_BASE="$2"; shift 2 ;;
    --runtime-dir) RUNTIME_DIR="$2"; shift 2 ;;
    --agent) AGENT="$2"; shift 2 ;;
    --catalina-script) CATALINA_SCRIPT="$2"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    --) shift; break ;;
    *) echo "Unknown option: $1" >&2; usage; exit 1 ;;
  esac
done

[ -d "$CATALINA_BASE" ] || { echo "Missing Tomcat directory: $CATALINA_BASE" >&2; usage; exit 1; }
[ -d "$RUNTIME_DIR" ] || { echo "Missing runtime directory: $RUNTIME_DIR" >&2; usage; exit 1; }
[ -f "$RUNTIME_DIR/bce.properties" ] || { echo "Missing runtime config: $RUNTIME_DIR/bce.properties" >&2; usage; exit 1; }
[ -f "$RUNTIME_DIR/license.bce" ] || { echo "Missing license: $RUNTIME_DIR/license.bce" >&2; usage; exit 1; }
[ -f "$AGENT" ] || { echo "Missing native agent: $AGENT" >&2; usage; exit 1; }

CATALINA_BASE="$(cd "$CATALINA_BASE" && pwd)"
RUNTIME_DIR="$(cd "$RUNTIME_DIR" && pwd)"
AGENT="$(cd "$(dirname "$AGENT")" && pwd)/$(basename "$AGENT")"
if [ -z "$CATALINA_SCRIPT" ]; then
  CATALINA_SCRIPT="$CATALINA_BASE/bin/catalina.sh"
fi
[ -f "$CATALINA_SCRIPT" ] || { echo "Missing catalina script: $CATALINA_SCRIPT" >&2; usage; exit 1; }

NATIVE_DIR="$(cd "$(dirname "$AGENT")" && pwd)"
export DYLD_LIBRARY_PATH="$NATIVE_DIR:${DYLD_LIBRARY_PATH:-}"
export LD_LIBRARY_PATH="$NATIVE_DIR:${LD_LIBRARY_PATH:-}"
export CATALINA_BASE
export CATALINA_OPTS="${CATALINA_OPTS:-} -XX:+DisableAttachMechanism -agentpath:$AGENT=$RUNTIME_DIR"

exec sh "$CATALINA_SCRIPT" run "$@"
