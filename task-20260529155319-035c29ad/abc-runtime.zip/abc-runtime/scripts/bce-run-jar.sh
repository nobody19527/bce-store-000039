#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'EOF'
Usage:
  ./bce-run-jar.sh [--jar app/app_encrypted.jar] [--] [application args...]

Examples:
  ./bce-run-jar.sh
  ./bce-run-jar.sh --server.port=18080 --spring.profiles.active=prod
  BCE_JAVA_OPTS="-Xmx512m" ./bce-run-jar.sh --server.port=18080

Expected package layout:
  app/
  native/
  scripts/
  bce.properties
  license.bce

Options:
  --jar       encrypted JAR path. If omitted, app.main.jar in bce.properties is used first.
  -h, --help  show this help.

The native agent validates license.bce online before the application starts.
EOF
}

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACKAGE_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
APP_JAR=""
ORIGINAL_ARG_COUNT=$#

while [ "$#" -gt 0 ]; do
  case "$1" in
    --jar)
      [ "$#" -ge 2 ] || { usage; exit 1; }
      APP_JAR="$2"
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    --)
      shift
      break
      ;;
    -*)
      break
      ;;
    *)
      if [ -z "$APP_JAR" ] && [[ "$1" == *.jar ]]; then
        APP_JAR="$1"
        shift
      fi
      break
      ;;
  esac
done

read_config_main_jar() {
  local config="$PACKAGE_DIR/bce.properties"
  [ -f "$config" ] || return 0
  local value
  value="$(sed -n 's/^app\.main\.jar=//p' "$config" | head -n 1 | tr -d '\r')"
  [ -n "$value" ] || return 0
  case "$value" in
    /*)
      printf '%s\n' "$value"
      ;;
    *)
      printf '%s\n' "$PACKAGE_DIR/app/$value"
      ;;
  esac
}

if [ -z "$APP_JAR" ]; then
  config_jar="$(read_config_main_jar)"
  if [ -n "$config_jar" ]; then
    if [ ! -f "$config_jar" ]; then
      echo "app.main.jar in bce.properties does not exist under app/: $config_jar" >&2
      usage
      exit 1
    fi
    APP_JAR="$config_jar"
  fi
fi

if [ -z "$APP_JAR" ]; then
  jars=("$PACKAGE_DIR"/app/*.jar)
  if [ ${#jars[@]} -ne 1 ] || [ ! -f "${jars[0]}" ]; then
    echo "Could not auto-detect encrypted JAR. Set app.main.jar, place exactly one JAR under app/, or pass --jar." >&2
    usage
    exit 1
  fi
  APP_JAR="${jars[0]}"
elif [ ! -f "$APP_JAR" ] && [ -f "$PACKAGE_DIR/app/$APP_JAR" ]; then
  APP_JAR="$PACKAGE_DIR/app/$APP_JAR"
fi

if [ "$ORIGINAL_ARG_COUNT" -eq 0 ]; then
  cat <<'EOF'
No application arguments were specified for this run.
To pass arguments to the encrypted JAR, append them after this script.
Example for a Spring Boot JAR:
  ./scripts/bce-run-jar.sh --server.port=18080 --spring.profiles.active=prod

EOF
fi

case "$(uname -s)" in
  Darwin)
    AGENT="$PACKAGE_DIR/native/libbkey.dylib"
    ;;
  Linux)
    AGENT="$PACKAGE_DIR/native/libbkey.so"
    ;;
  *)
    echo "Unsupported OS. On Windows, use scripts/bce-run-jar-windows.ps1." >&2
    exit 1
    ;;
esac

CORE="$SCRIPT_DIR/bce-core-run-jar.sh"
exec "$CORE" \
  --jar "$APP_JAR" \
  --runtime-dir "$PACKAGE_DIR" \
  --agent "$AGENT" \
  -- "$@"
