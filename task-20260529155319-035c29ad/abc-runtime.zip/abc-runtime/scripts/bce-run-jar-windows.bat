@echo off
powershell -ExecutionPolicy Bypass -File "%~dp0bce-run-jar-windows.ps1" %*
pause
